/**
   MLX90640 I2C driver header - ESP32 adjusted version
   Based on Melexis/SparkFun MLX90640 driver.
*/
#ifndef _MLX90640_I2C_DRIVER_H_
#define _MLX90640_I2C_DRIVER_H_

#include <stdint.h>

// ESP32 Arduino Wire buffer is normally 128 bytes. Define it here if the
// core did not expose it before this header is included.
#ifndef I2C_BUFFER_LENGTH
  #if defined(ARDUINO_ARCH_ESP32)
    #define I2C_BUFFER_LENGTH 128
  #elif defined(BUFFER_LENGTH)
    #define I2C_BUFFER_LENGTH BUFFER_LENGTH
  #else
    #define I2C_BUFFER_LENGTH 32
  #endif
#endif

void MLX90640_I2CInit(void);
int MLX90640_I2CRead(uint8_t slaveAddr, unsigned int startAddress, unsigned int nWordsRead, uint16_t *data);
int MLX90640_I2CWrite(uint8_t slaveAddr, unsigned int writeAddress, uint16_t data);
void MLX90640_I2CFreqSet(int freq);

#endif
