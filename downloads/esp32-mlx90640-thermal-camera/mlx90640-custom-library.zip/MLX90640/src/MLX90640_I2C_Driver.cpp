/**
   MLX90640 I2C driver - ESP32 adjusted version
   SDA/SCL are initialized in the main .ino using Wire.begin(21, 22).
*/
#include <Arduino.h>
#include <Wire.h>
#include "MLX90640_I2C_Driver.h"

void MLX90640_I2CInit()
{
  // Wire.begin() is called in the main sketch so custom ESP32 pins can be used.
}

// Read nWordsRead 16-bit words from the MLX90640 register map.
// Returns 0 on success, negative value on error.
int MLX90640_I2CRead(uint8_t slaveAddr, unsigned int startAddress, unsigned int nWordsRead, uint16_t *data)
{
  uint16_t wordsRemaining = nWordsRead;
  uint16_t dataSpot = 0;

  while (wordsRemaining > 0)
  {
    // Number of 16-bit words to read in this I2C transaction.
    uint16_t wordsToRead = wordsRemaining;
    uint16_t maxWordsPerRead = I2C_BUFFER_LENGTH / 2;
    if (wordsToRead > maxWordsPerRead) wordsToRead = maxWordsPerRead;

    uint16_t bytesToRead = wordsToRead * 2;

    Wire.beginTransmission(slaveAddr);
    Wire.write(startAddress >> 8);
    Wire.write(startAddress & 0xFF);

    // Repeated-start read.
    if (Wire.endTransmission(false) != 0)
    {
      return -1;
    }

    uint16_t bytesReceived = Wire.requestFrom((uint8_t)slaveAddr, (size_t)bytesToRead, (bool)true);
    if (bytesReceived != bytesToRead)
    {
      // Flush anything that did arrive.
      while (Wire.available()) Wire.read();
      return -2;
    }

    for (uint16_t i = 0; i < wordsToRead; i++)
    {
      uint16_t value = ((uint16_t)Wire.read()) << 8;
      value |= (uint16_t)Wire.read();
      data[dataSpot++] = value;
    }

    wordsRemaining -= wordsToRead;
    startAddress += wordsToRead;
  }

  return 0;
}

// Set I2C frequency in kHz. Example: MLX90640_I2CFreqSet(400) = 400 kHz.
void MLX90640_I2CFreqSet(int freq)
{
  Wire.setClock((uint32_t)freq * 1000UL);
}

// Write one 16-bit word to a 16-bit MLX90640 register address.
// Returns 0 on success, negative value on error.
int MLX90640_I2CWrite(uint8_t slaveAddr, unsigned int writeAddress, uint16_t data)
{
  Wire.beginTransmission(slaveAddr);
  Wire.write(writeAddress >> 8);
  Wire.write(writeAddress & 0xFF);
  Wire.write(data >> 8);
  Wire.write(data & 0xFF);

  if (Wire.endTransmission() != 0)
  {
    return -1;
  }

  uint16_t dataCheck = 0;
  int readStatus = MLX90640_I2CRead(slaveAddr, writeAddress, 1, &dataCheck);
  if (readStatus != 0)
  {
    return readStatus;
  }

  if (dataCheck != data)
  {
    return -2;
  }

  return 0;
}
