#!/usr/bin/env bash
# Evidence profile only. Never execute resulting G-code blindly on a printer.
set -euo pipefail
ROOT=$(cd -- "$(dirname -- "$0")" && pwd)
REV=${1:-revision-m}
SLICER=${PRUSA_SLICER:-/tmp/opencode/pigpulse-slicer/runtime/usr/bin/prusa-slicer}
export LD_LIBRARY_PATH="/tmp/opencode/pigpulse-slicer/runtime/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
test -x "$SLICER"
mkdir -p "$ROOT/$REV/slicer"
for f in "$ROOT/$REV"/*.stl; do
  n=$(basename "$f" .stl)
  support=()
  case "$n" in thermal_angled_hood|thermal_raised_cradle)
    support=(--support-material --support-material-buildplate-only);;
  esac
  "$SLICER" --export-gcode --layer-height 0.2 --nozzle-diameter 0.4 \
    --perimeters 4 --fill-density '20%' --temperature 235 \
    --first-layer-temperature 235 --bed-temperature 80 \
    --first-layer-bed-temperature 80 --filament-type PETG \
    --bed-shape '0x0,220x0,220x220,0x220' "${support[@]}" \
    --output "$ROOT/$REV/slicer/$n.gcode" "$f" > "$ROOT/$REV/slicer/$n.log" 2>&1
done
node "$ROOT/summarize_verification.js" "$REV"
