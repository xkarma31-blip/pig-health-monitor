"""Discrete escape-channel probe; not complete tie bend/head compatibility."""
import bpy
import json
import hashlib
from pathlib import Path
from mathutils import Vector

root=Path(__file__).resolve().parent
reports=[]
for revision in ('revision-n','revision-o'):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.import_mesh.stl(filepath=str(root/revision/'microphone_strap_carrier.stl'))
    obj=bpy.context.object
    samples=[]
    for sign in (-1,1):
        for x in (11.2,11.8,12.4):
            for y in (-2,0,2):
                hit,p,_,_=obj.ray_cast(Vector((sign*x,y,5)),Vector((0,0,-1)))
                samples.append({'xy':[sign*x,y],'floor_z_mm':p.z if hit else None,
                                'clearance_mm':3-p.z if hit else None,
                                'pass':hit and p.z<=1.85})
    reports.append({'revision':revision,'pass':all(s['pass'] for s in samples),'samples':samples})
report={'method':'18 downward rays through outward escape channels; requires >=1.15mm nominal face-side clearance at sampled locations.',
        'limitations':'Not continuous route proof; tie thickness,width,bend radius and locking head unmeasured. Slot bends and real print fit untested.',
        'results':reports}
report['input_sha256']={r:hashlib.sha256((root/r/'microphone_strap_carrier.stl').read_bytes()).hexdigest() for r in ('revision-n','revision-o')}
(root/'revision-o/strap-relief-comparison.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'negative_control_n':reports[0]['pass'],'repaired_o':reports[1]['pass']}))
if reports[0]['pass'] or not reports[1]['pass']:
    raise SystemExit(1)
