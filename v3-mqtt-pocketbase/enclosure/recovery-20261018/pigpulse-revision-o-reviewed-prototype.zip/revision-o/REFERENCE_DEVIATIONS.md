# Reference correspondence — unresolved differences, not a fidelity score

Latest two-image review retained as reference-visual-review.txt. It supports
readable source wordmark/full tagline,charcoal three-module stack and mint dual
port accents. It does NOT establish high-fidelity equivalence.

## Genuine visible differences

- Poster illustrates inter-module collars. O uses a common rear bolted spine,
  with short gaps and no fitted cables rendered. Front view can suggest floating
  pods; rear view shows their actual attachment. No twist-lock mechanism exists.
- Thermal opening is rectangular and empty,not the illustrated fitted circular
  optic. Inserting a decorative ring without actual sensor free-zone dimensions
  risks obstruction. This remains an honest but visually significant difference.
- Main sides lack illustrated external hinge/latch/mounting-lug details. Current
  cover is through-bolted,not hinged. Dummy mechanisms would misrepresent assembly.
- Acoustic face has visible carrier fasteners and optional thick accent rings;
  no grille or acoustic membrane is fitted or validated.
- External SHT carrier changes silhouette and width. It is not a wall bracket.

## Reviewer inferences rejected

Reviewer describes countersunk fasteners and an articulated wall-mount arm. Head
proxies are not proof of countersink design; arm is rigid SHT support. Review also
contradicts itself about whether source mint accents belong to ports. Use original
image and geometric evidence,not those inferred roles,to guide decisions.

## Remaining decision boundary

Do not equate preserved artwork or passing digital gates with finished source
fidelity. Mechanical redesign toward real hinges/collars requires actual joint
requirements,not decorative imitation. Fitted optic/grille appearance requires
actual sensor integration. Current case is a reviewed prototype,not final approved
replica. No physical validation or arbitrary aesthetic percentage is claimed.
