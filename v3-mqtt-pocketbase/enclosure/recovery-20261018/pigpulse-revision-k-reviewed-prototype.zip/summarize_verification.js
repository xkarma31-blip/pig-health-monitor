const fs=require('fs'),path=require('path');
const p=path.join(__dirname,process.argv[2]||'revision-h');
const e=JSON.parse(fs.readFileSync(path.join(p,'export-checks.json')));
const a=JSON.parse(fs.readFileSync(path.join(p,'assembly-checks.json')));
const parts=e.results.map(x=>{
 const log=fs.readFileSync(path.join(p,'slicer',x.part+'.log'),'utf8');
 const g=fs.readFileSync(path.join(p,'slicer',x.part+'.gcode'),'utf8');
 const match=k=>(g.match(new RegExp('^; '+k+' = (.+)$','m'))||[])[1];
 return {part:x.part,triangles:x.triangles,export_pass:x.pass,
   slicing_success:log.includes('Slicing result exported'),
   warning:/print warning|error:/i.test(log),layers:(g.match(/;LAYER_CHANGE/g)||[]).length,
   toolpath_moves:(g.match(/^G1 /gm)||[]).length,
   support_enabled:match('support_material'),
   bed_temperature:match('bed_temperature'),temperature:match('temperature'),
   nozzle_diameter:match('nozzle_diameter'),filament_type:match('filament_type')};
});
const report={export_gate:e.pass,assembly_pair_gate:a.pair_intersection_gate,
  all_installed_intersection_gate:a.all_installed_intersection_gate,
  cradle_head_clearance_gate:a.cradle_head_clearance_gate,
  installed_part_count:a.installed_part_count,
  assembly_pair_count:a.pairs.length,slicer:'PrusaSlicer 2.7.2',
  parts,pass:e.pass&&a.pair_intersection_gate&&a.all_installed_intersection_gate&&a.cradle_head_clearance_gate&&parts.every(x=>x.export_pass&&x.slicing_success&&!x.warning&&x.layers>0&&x.toolpath_moves>0),
  limitations:['No physical fit or print test','No electronic hardware measurements',
    'No self-intersection proof or structural analysis','G-code for assumed profile, not user printer approval',
    'No IP rating or sensor performance certification']};
fs.writeFileSync(path.join(p,'verification-summary.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify({pass:report.pass,parts:parts.length,assemblyPairs:a.pairs.length}));
process.exitCode=report.pass?0:1;
