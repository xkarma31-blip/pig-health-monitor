"""Read-only assembly intersection audit; temporary boolean copies only."""
import bpy
import bmesh
import json
import os
from pathlib import Path
from mathutils import Vector

out=Path(__file__).resolve().parent/os.environ.get('PIGPULSE_REVISION','revision-k')
bpy.ops.wm.open_mainfile(filepath=str(out/'assembled-review.blend'))

def bounds(o):
    vs=[o.matrix_world@Vector(v) for v in o.bound_box]
    return {'min':[min(v[k] for v in vs) for k in range(3)],
            'max':[max(v[k] for v in vs) for k in range(3)]}

def overlap(a,b):
    a=bpy.data.objects[a];b=bpy.data.objects[b]
    aa,bb=bounds(a),bounds(b)
    # Exact coplanar contact can produce boolean solver residue. Reject pairs
    # with no volumetric AABB penetration before invoking that solver.
    if any(min(aa['max'][k],bb['max'][k])-max(aa['min'][k],bb['min'][k])<=0.0001 for k in range(3)):
        return 0.0
    c=a.copy();c.data=a.data.copy();bpy.context.collection.objects.link(c)
    bpy.context.view_layer.objects.active=c
    mod=c.modifiers.new('audit intersection','BOOLEAN')
    mod.operation='INTERSECT';mod.solver='EXACT';mod.object=b
    bpy.ops.object.modifier_apply(modifier=mod.name)
    bm=bmesh.new();bm.from_mesh(c.data)
    vol=abs(bm.calc_volume(signed=True));bm.free()
    bpy.data.objects.remove(c,do_unlink=True)
    return vol

pairs=[('main_tub','main_lid'),('thermal_tub','thermal_face'),
       ('thermal_face','thermal_angled_hood'),('acoustic_tub','acoustic_face'),
       ('mounting_spine','main_tub'),('mounting_spine','thermal_tub'),
       ('mounting_spine','acoustic_tub'),('mounting_spine','sht_mount_arm'),
       ('sht_mount_arm','sht_adjustable_carrier'),('main_tub','electronics_strap_tray'),
       ('thermal_face','thermal_raised_cradle'),('thermal_angled_hood','thermal_raised_cradle'),
       ('acoustic_face','microphone_strap_carrier')]
report={'method':'Exact boolean intersection of assembled exported STL meshes',
        'not_tested':['physical fit','electronic component interference','screw head/nut tool access','self intersections'],
        'parts':{n:bounds(bpy.data.objects[n]) for n in set(sum(([a,b] for a,b in pairs),[]))},
        'pairs':[{'a':a,'b':b,'overlap_mm3':overlap(a,b)} for a,b in pairs]}
report['pair_intersection_gate']=all(x['overlap_mm3']<0.01 for x in report['pairs'])
# Extend beyond hand-selected mating pairs. Broad-phase AABB rejects disjoint
# parts, exact boolean tests each remaining installed printable mesh pair.
installed=[o for o in bpy.data.objects if o.type=='MESH' and not o.hide_render
           and not o.name.startswith(('PURCHASED_','REFERENCE_'))]
all_checks=[]
for i,a in enumerate(installed):
    for b in installed[i+1:]:
        aa,bb=bounds(a),bounds(b)
        if all(min(aa['max'][k],bb['max'][k])-max(aa['min'][k],bb['min'][k])>0.0001 for k in range(3)):
            all_checks.append({'a':a.name,'b':b.name,'overlap_mm3':overlap(a.name,b.name)})
report['installed_part_count']=len(installed)
report['all_broadphase_candidate_pairs']=all_checks
report['all_installed_intersection_gate']=all(x['overlap_mm3']<0.01 for x in all_checks)
# Purchased fastener keep-outs: explicit assumptions, not real hardware meshes.
# Cradle is fixed to the separator BEFORE hood installation; driver path checked
# with hood removed, installed head envelopes checked with hood fitted.
head_checks=[]
for x in (-30,30):
    for y in (-9,9):
        top=9.2+y*__import__('math').tan(__import__('math').radians(15))
        bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=3,depth=2.4,
            location=(x,-(17+top+1.2),80+y),rotation=(__import__('math').pi/2,0,0))
        head=bpy.context.object;head.name='AUDIT_cradle_head'
        v=overlap(head.name,'thermal_angled_hood')
        head_checks.append({'x':x,'local_y':y,'head_radius_mm':3,
            'head_plus_washer_height_mm':2.4,'hood_collision_mm3':v})
        bpy.data.objects.remove(head,do_unlink=True)
report['cradle_head_envelopes']=head_checks
report['cradle_head_clearance_gate']=all(x['hood_collision_mm3']<0.01 for x in head_checks)
report['driver_access_assumption']='Install cradle on separator with hood removed; open axial access before final hood installation. Full driver geometry not simulated.'
(out/'assembly-checks.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report))
