const fs=require('fs'),path=require('path');
const crypto=require('crypto');
const p=path.join(__dirname,process.argv[2]||'revision-n');
const e=JSON.parse(fs.readFileSync(path.join(p,'export-checks.json')));
const ledgerPath=path.join(p,'fastener-ledger.json');
const ledger=fs.existsSync(ledgerPath)?JSON.parse(fs.readFileSync(ledgerPath)):null;
const gripPath=path.join(p,'grip-surface-checks.json');
const grip=fs.existsSync(gripPath)?JSON.parse(fs.readFileSync(gripPath)):null;
const gripGate=grip?.pass===true&&grip.checks?.length===11&&grip.checks.every(c=>c.pass===true)&&['thermal_angled_hood','thermal_raised_cradle','sht_mount_arm','tray_spacer_6mm'].every(n=>grip.input_stl_sha256?.[n]===e.results.find(x=>x.part===n)?.sha256);
const ledgerGate=ledger?.pass===true&&ledger.rows?.length===10&&ledger.rows.every(r=>r.length_gate===true&&r.assumed_bolt_length_mm>=r.nominal_grip_mm+4.4)&&e.results.every(x=>ledger.input_stl_sha256?.[x.part]===x.sha256);
const a=JSON.parse(fs.readFileSync(path.join(p,'assembly-checks.json')));
const bearingPath=path.join(p,'bearing-seat-checks.json');
const bearing=fs.existsSync(bearingPath)?JSON.parse(fs.readFileSync(bearingPath)):null;
const exportFresh=e.results.every(x=>x.sha256===crypto.createHash('sha256').update(fs.readFileSync(path.join(p,x.part+'.stl'))).digest('hex'));
const bearingFresh=['thermal_raised_cradle','thermal_angled_hood'].every(n=>bearing?.input_sha256?.[n]===crypto.createHash('sha256').update(fs.readFileSync(path.join(p,n+'.stl'))).digest('hex'));
const manifestPath=path.join(p,'assembly-import-manifest.json');
const manifest=fs.existsSync(manifestPath)?JSON.parse(fs.readFileSync(manifestPath)):{};
const assemblyFresh=a.scene_sha256===crypto.createHash('sha256').update(fs.readFileSync(path.join(p,'assembled-review.blend'))).digest('hex')&&e.results.every(x=>a.stl_sha256?.[x.part]===x.sha256&&manifest[x.part]===x.sha256&&a.scene_imported_stl_sha256?.[x.part]===x.sha256);
const sliceManifestPath=path.join(p,'slicer','input-manifest.json');
const sliceManifest=fs.existsSync(sliceManifestPath)?JSON.parse(fs.readFileSync(sliceManifestPath)):{};
const hash=f=>crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const slicerFresh=e.results.every(x=>sliceManifest[x.part]?.stl_sha256===x.sha256&&sliceManifest[x.part]?.gcode_sha256===hash(path.join(p,'slicer',x.part+'.gcode'))&&sliceManifest[x.part]?.log_sha256===hash(path.join(p,'slicer',x.part+'.log')));
const parts=e.results.map(x=>{
 const log=fs.readFileSync(path.join(p,'slicer',x.part+'.log'),'utf8');
 const g=fs.readFileSync(path.join(p,'slicer',x.part+'.gcode'),'utf8');
 const match=k=>(g.match(new RegExp('^; '+k+' = (.+)$','m'))||[])[1];
 return {part:x.part,triangles:x.triangles,export_pass:x.pass,
   slicing_success:log.includes('Slicing result exported'),
   warning:/print warning|error:/i.test(log),layers:(g.match(/;LAYER_CHANGE/g)||[]).length,
   toolpath_moves:(g.match(/^G1 /gm)||[]).length,
   support_enabled:match('support_material'),
   bed_temperature:match('bed_temperature'),temperature:match('temperature'),
   nozzle_diameter:match('nozzle_diameter'),filament_type:match('filament_type')};
});
const report={export_gate:e.pass,export_hash_freshness_gate:exportFresh,assembly_pair_gate:a.pair_intersection_gate,
  all_installed_intersection_gate:a.all_installed_intersection_gate,
  cradle_head_clearance_gate:a.cradle_head_clearance_gate,
  cradle_driver_gate:a.cradle_driver_gate===true,
  sht_joint_hardware_gate:a.sht_joint_hardware_gate===true,
  provisional_fastener_ledger_gate:ledgerGate,
  selected_grip_surface_gate:gripGate,
  installed_inventory_gate:a.installed_inventory_gate===true&&a.installed_part_count===20,
  annular_bearing_seat_gate:bearing?.pass??false,
  bearing_hash_freshness_gate:bearingFresh,
  assembly_hash_freshness_gate:assemblyFresh,
  slicer_hash_freshness_gate:slicerFresh,
  installed_part_count:a.installed_part_count,
  assembly_pair_count:a.pairs.length,slicer:'PrusaSlicer 2.7.2',
  parts,pass:gripGate&&a.installed_inventory_gate===true&&a.installed_part_count===20&&ledgerGate&&a.sht_joint_hardware_gate===true&&slicerFresh&&assemblyFresh&&bearingFresh&&exportFresh&&e.pass&&a.pair_intersection_gate&&a.all_installed_intersection_gate&&a.cradle_head_clearance_gate&&a.cradle_driver_gate===true&&bearing?.pass===true&&parts.every(x=>x.export_pass&&x.slicing_success&&!x.warning&&x.layers>0&&x.toolpath_moves>0),
  limitations:['No physical fit or print test','No electronic hardware measurements',
    'No self-intersection proof or structural analysis','G-code for assumed profile, not user printer approval',
    'No IP rating or sensor performance certification']};
fs.writeFileSync(path.join(p,'verification-summary.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify({pass:report.pass,parts:parts.length,assemblyPairs:a.pairs.length}));
process.exitCode=report.pass?0:1;
