# Latest reviewed checkpoint: N

Use revision-n/README.md, ASSEMBLY_CURRENT.md and PHYSICAL_VALIDATION_REQUIRED.md.
Earlier CONTINUE_FROM_K.md is historical and superseded. No firmware/services edits.

Actual repairs since H include thermal bearing/fastener clearance,rounded shells,
original-art label presentation,mint trim and SHT hardware clearance notches.
Independent visual and mechanical critiques preserved,including negative results.
No exact poster replication,physical fit,IP,sensor performance or field readiness.

Fresh verify_revision.sh revision-n run passes17 exports,13 selected pairs,20-object
inventory/all-pairs screening,576 bearing samples,cradle head/limited driver and
SHT joint hardware envelopes,provisional length ledger and17 actual slicer jobs.
Input-hash gates and negative controls catch several stale-evidence paths.
Hard-coded dimensions and discrete tests remain limited,not formal correctness.

ZIP integrity passes; all9 packaged workflow scripts byte-match current files;
zero G-code entries. G-code excluded intentionally; rerun to reproduce summary.
Original asset preserved. Archive SHA256 alongside. No commit/push performed.

Goal remains active. Next: inspect latest N views against original with independent
vision reviewer; verify notch appearance and remaining source discrepancies. Avoid
substituting more evidence infrastructure for unresolved aesthetic/mechanical work.
Physical tests explicitly require actual boards,printer and bench measurement;
do not report their absence as completed validation.
